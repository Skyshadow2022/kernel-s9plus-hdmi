#!/system/bin/sh
# Safe DP/HDMI helper for PE — does NOT touch HPD killers.
LOG=/data/local/tmp/dp-hdmi-helper.log
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

# Mirror policy only (not DeX desktop). Never write dp_drm / forced_resolution / bist.
[ -e /sys/class/dp_sec/dex ] && echo 0 > /sys/class/dp_sec/dex 2>/dev/null
[ -e /sys/class/dp_sec/log_level ] && echo 7 > /sys/class/dp_sec/log_level 2>/dev/null
[ -e /sys/class/dp_sec/prefer_live ] && echo 1 > /sys/class/dp_sec/prefer_live 2>/dev/null

# Unblank external fb only — leave bist alone (kernel prefer_live handles live/BIST).
if grep -q 'DP=1' /sys/class/extcon/extcon0/state 2>/dev/null; then
  timeout 5 sh -c 'echo 0 > /sys/class/graphics/fb1/blank' 2>/dev/null
fi

log "mon=$(cat /sys/class/dp_sec/monitor_info 2>/dev/null) ext=$(cat /sys/class/extcon/extcon0/state 2>/dev/null) prefer=$(cat /sys/class/dp_sec/prefer_live 2>/dev/null) bist=$(cat /sys/class/dp_sec/bist 2>/dev/null)"
